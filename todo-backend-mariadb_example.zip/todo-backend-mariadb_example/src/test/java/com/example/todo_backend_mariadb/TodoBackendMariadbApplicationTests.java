package com.example.todo_backend_mariadb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoBackendMariadbApplicationTests {

	@Test
	void contextLoads() {
	}

}
